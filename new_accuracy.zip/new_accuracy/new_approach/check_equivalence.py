from z3 import *
def read_dimacs_and_make_SAT_formula(file_name: str):
    vars = dict()
    base_name = "x"
    with open(file_name, "r") as f:
        for idx, line in enumerate(f):
            if line.strip() != "\n" and line.strip() != "" and line.strip() != "\r" and line.strip() != None and idx > 0:
                splitted_vals = line.split()
                for element in splitted_vals:
                    if int(element) != 0:
                        if int(element) > 0 and vars.get(element) is None:
                            # pure variable which never seen
                            vars[element] = Bool(base_name+element)
                        elif int(element) > 0 and vars.get("-"+element) is not None:
                            # pure variable we have seen the negetion before.
                            vars[element] = Not(vars["-"+element])
                        elif int(element) < 0 and vars.get("-"+element) is None:
                            # negetion of a variable and we have not seen it before.
                            vars[element] = Not(Bool(base_name+element.replace("-", "")))
                        elif int(element) < 0 and vars.get(element.replace("-", "")) is not None:
                            # Negetion, we have seen the pure variable before.
                            vars[element] = Not(vars[element.replace("-", "")])
        f.seek(0)
        disjunctions = []
        for idx, line in enumerate(f):
            clauses = []
            if line.strip() != "\n" and line.strip() != "" and line.strip() != "\r" and line.strip() != None and idx > 0:
                splitted_vals = line.split()
                for element in splitted_vals:
                    if int(element) != 0:
                        clauses.append(vars[element])
                disjunctions.append(Or([*clauses]))
        # print(disjunctions)
        if disjunctions:
            return And([*disjunctions])
        return None
def parse_dimacs_file(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        clauses = []
        for line in lines:
            if line.startswith("c") or line.startswith("p"):
                continue
            clause = [int(literal) for literal in line.split()[:-1]]
            clauses.append(clause)
    return clauses

def create_z3_formula(clauses):
    variables = set(abs(literal) for clause in clauses for literal in clause)
    z3_variables = {var: Bool(f'x_{var}') for var in variables}
    z3_clauses = [Or([z3_variables[abs(literal)] if literal > 0 else Not(z3_variables[abs(literal)]) for literal in clause]) for clause in clauses]
    return And(z3_clauses)

if __name__== "__main__":
            s = Solver()

            #disjunctions = read_dimacs_and_make_SAT_formula("bnntocnf.cnf")
            #if disjunctions is not None:
            #    s.add(disjunctions)
            #    print(s.check())
            #    if s.check().r != -1:
            #       model=s.model()
            """
            s.from_file("bnntocnf.cnf")
            print(s)
            print(s.check())
            model=s.model()
            model_dict = {d.name(): model[d] for d in model.decls()}

            last_20_assignments = list(model_dict.items())[:18]
            print('Number of Variables :',len(list(model_dict.items())))
            variables_to_check = ['k!1' ,'k!2', 'k!3', 'k!4', 'k!5','k!6','k!7','k!8','k!9','k!10','k!11','k!12',
                                   'k!13','k!14','k!15','k!16','k!17','k!18' ]

            # Print the last 20 assignments
            for variable, value in last_20_assignments:
                print(f"{variable} = {value}")
            for variable in variables_to_check:
                # Check if the variable exists and print its value
                if variable in model_dict:
                    variable_value = model_dict[variable]
                    print(f"Variable {variable} exists with value: {variable_value}")
                else:
                    print(f"Variable {variable} does not exist in the model.")"""

            # Assuming cnf1_file and cnf2_file are the paths to your CNF files
            cnf1_file = "bnntocnf.cnf"
            cnf2_file = "neg_bdd.cnf"
            """solver1=Solver()
            solver2=Solver()

            # Create solvers and read CNF formulas from files
            solver1.from_file(filename=cnf1_file)
            solver2.from_file(filename=cnf2_file)

            # Conjunction: add all clauses from solver2 to solver1
            solver2.check()
            print('Checking...', solver2.model())
            print('Assertions :', solver2.assertions())
            conjunction_solver=Solver()
            conjunction_solver.add(And(solver1.assertions(), solver2.assertions()))
            #solver1.add(solver2.assertions())

            # Check satisfiability
            result = conjunction_solver.check()

            if result == sat:
                print("The conjunction of the CNF formulas is satisfiable.")
                model = solver1.model()
                model_dict = {d.name(): model[d] for d in model.decls()}

                # Print satisfying assignment for shared variables
                shared_variables = {'k!2', 'k!4', 'k!6', 'k!8', 'k!9'}

                for variable in shared_variables:
                    if variable in model_dict:
                        variable_value = model_dict[variable]
                        print(f"Variable {variable} exists with value: {variable_value}")
                    else:
                        print(f"Variable {variable} does not  exist")
            else:
                print("The conjunction of the CNF formulas is unsatisfiable.")"""
            clauses1 = parse_dimacs_file(cnf1_file)
            clauses2 = parse_dimacs_file(cnf2_file)

            formula1 = create_z3_formula(clauses1)
            formula2 = create_z3_formula(clauses2)
            print(formula1)
            bdd_solver=Solver()
            bdd_solver.add(formula2)
            bdd_solver.check()
            print('Z3 Model 1: ', bdd_solver.model()) 
            #bnn_solver=Solver()
            #bnn_solver.add(formula1)
            #bnn_solver.check()
            #print('Z3 Model 2: ', bnn_solver.model())

            conjunction_formula = And(formula1, formula2)

            solver = Solver()

            solver.add(conjunction_formula)

            print("Is the conjunction satisfiable?", solver.check())

            if solver.check() == sat:
                model = solver.model()
                print("Model:", model)