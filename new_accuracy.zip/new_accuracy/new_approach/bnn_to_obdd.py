#!/usr/bin/env python3

from circuits.timer import Timer
from circuits.linear import *
from keras.models import Sequential
from keras.layers import Dense
from tensorflow.keras.initializers import  RandomNormal

def print_model(model):
    model_vars = sorted(model.keys())
    print(" ".join("%d:%d" % (var,model[var]) for var in model_vars))

if __name__ == '__main__':
    filename = 'examples/example.neuron'
    # c = Classifier.read(filename)
    keras_model=Sequential()
    keras_model.add(Dense(units=10, activation='relu', input_dim=10,kernel_initializer=RandomNormal(mean=10.0, stddev=0.05)))
    keras_weights=keras_model.get_weights()[0]
    for i in range(len( keras_weights)):
        print('weights : ',[ w for w in keras_weights[i]])
        weights = [int(weight) for weight in keras_weights[i]]
        c =Classifier(name='test keras', size=str(len(weights)), weights=weights, threshold=10)

    print("=== INPUT NEURON:")
    print('Classifier Content :',c)
    assert c.is_integer
    #c = c.with_precision(3)
    #print("== quantized neuron:")
    #print(c)
    print("=== NEURON TO OBDD:")
    with Timer("compiling"):
        obdd_manager,node = c.compile()
    with Timer("size"):
        count_before = len(list(node))
    with Timer("reducing"):
        node = node.reduce()
    with Timer("size"):
        count_after = len(list(node))
    print("node count before reduce: %d" % count_before)
    print(" node count after reduce: %d" % count_after)

    print("=== OBDD:")
    print("model count: %d" % node.model_count(obdd_manager.var_count))
    print("models:")
    for model in node.models():
        print_model(model)
    print("non-models:")
    for model in node.non_models():
        print_model(model)

    # save the obdd to a png, using pyeda and pydot (install these)
    png_filename = filename + ".png"
    obdd_manager.obdd_to_png(node,png_filename)
    print("saved obdd image to %s" % png_filename)
    cnf,output_wire=obdd_manager.obdd_to_cnf(node, 1)
    dimacs_file_path = 'output.cnf'
    with open(dimacs_file_path, 'w') as dimacs_file:
        dimacs_file.write(f"p cnf {cnf.var_count} {len(cnf.clauses)}\n")
        for clause in cnf.clauses:
            dimacs_file.write(" ".join(map(str, clause)) + " 0\n")
    print('=== CNF')
    print('Clauses')
    for cl in cnf.clauses:
        print(cl)
    print('Output Wire in CNF:', output_wire)

    #obdd_manager.save_vtree("tmp.vtree")
    #obdd_manager.save_sdd("tmp.sdd",node)
