from z3 import *

def read_cnf(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    clauses = []
    for line in lines:
        if line.startswith('c') or line.startswith('p'):
            continue
        clause = [int(literal) for literal in line.split()[:-1]]
        clauses.append(clause)
    return clauses

def apply_and_operator(solver, cnf_file):
    clauses = read_cnf(cnf_file)
    for clause in clauses:
        solver.add(Or([Bool(f"x_{literal}") if literal > 0 else Not(Bool(f"x_{-literal}")) for literal in clause]))
        print(clause)

if __name__ == "__main__":
    cnf_files = ['cnf_layer_1.cnf', 'cnf_layer_2.cnf', 'cnf_layer_3.cnf', 'cnf_layer_4.cnf', 'cnf_layer_5.cnf', 'cnf_layer_6.cnf',
 'cnf_layer_7.cnf', 'cnf_layer_8.cnf', 'cnf_layer_9.cnf', 'cnf_layer_10.cnf', 'cnf_layer_11.cnf', 'cnf_layer_12.cnf',
 'cnf_layer_13.cnf', 'cnf_layer_14.cnf', 'cnf_layer_15.cnf', 'cnf_layer_16.cnf', 'cnf_layer_17.cnf', 'cnf_layer_18.cnf',
 'cnf_layer_19.cnf', 'cnf_layer_20.cnf', 'cnf_layer_21.cnf', 'cnf_layer_22.cnf', 'cnf_layer_23.cnf', 'cnf_layer_24.cnf', 
'cnf_layer_25.cnf', 'cnf_layer_26.cnf', 'cnf_layer_27.cnf', 'cnf_layer_28.cnf', 'cnf_layer_29.cnf', 'cnf_layer_30.cnf',
 'cnf_layer_31.cnf', 'cnf_layer_32.cnf', 'cnf_layer_33.cnf', 'cnf_layer_34.cnf', 'cnf_layer_35.cnf', 'cnf_layer_36.cnf']

    # Create Z3 solver

    solver = Solver()

    # Apply AND operator on each CNF file
    for cnf_file in cnf_files:
        solver.from_file(filename=cnf_file)
        #apply_and_operator(solver, cnf_file)

    # Check satisfiability
    result = solver.check()
    if result == sat:
        print("Satisfiable")
        model = solver.model()
        for d in model.decls():
            print(f"{d.name()} = {model[d]}")
    else:
        print("Unsatisfiable")

