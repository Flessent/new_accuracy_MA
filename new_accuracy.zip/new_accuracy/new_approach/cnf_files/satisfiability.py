from z3 import *
from pysat.solvers import Glucose3
from pysat.formula import CNF

def read_cnf(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    clauses = []
    for line in lines:
        if line.startswith('c') or line.startswith('p'):
            continue
        clause = [int(literal) for literal in line.split()[:-1]]
        clauses.append(clause)
    return clauses

def apply_and_recursive(solver, cnf_files, index=0):
    if index == len(cnf_files) - 1:
        apply_and_operator(solver, cnf_files[index])
    else:
        apply_and_operator(solver, cnf_files[index])
        apply_and_recursive(solver, cnf_files, index + 1)

def apply_and_operator(solver, cnf_file):
    clauses = read_cnf(cnf_file)
    for clause in clauses:
        solver.add(Or([Bool(f"x_{literal}") if literal > 0 else Not(Bool(f"x_{-literal}")) for literal in clause]))

if __name__ == "__main__":
    cnf_files =['cnf_neuron_1.cnf', 'cnf_neuron_2.cnf', 'cnf_neuron_3.cnf', 'cnf_neuron_4.cnf', 'cnf_neuron_5.cnf', 'cnf_neuron_6.cnf', 'cnf_neuron_7.cnf', 'cnf_neuron_8.cnf', 
'cnf_neuron_9.cnf', 'cnf_neuron_10.cnf', 'cnf_neuron_11.cnf', 'cnf_neuron_12.cnf', 'cnf_neuron_13.cnf', 'cnf_neuron_14.cnf', 'cnf_neuron_15.cnf', 'cnf_neuron_16.cnf', 'cnf_neuron_17.cnf', 'cnf_neuron_18.cnf',
 'cnf_neuron_19.cnf', 'cnf_neuron_20.cnf', 'cnf_neuron_21.cnf', 'cnf_neuron_22.cnf', 'cnf_neuron_23.cnf', 'cnf_neuron_24.cnf', 'cnf_neuron_25.cnf', 'cnf_neuron_26.cnf', 'cnf_neuron_27.cnf',
 'cnf_neuron_28.cnf', 'cnf_neuron_29.cnf', 'cnf_neuron_30.cnf', 'cnf_neuron_31.cnf', 'cnf_neuron_32.cnf', 'cnf_neuron_33.cnf', 'cnf_neuron_34.cnf', 'cnf_neuron_35.cnf', 'cnf_neuron_36.cnf', 
'cnf_neuron_37.cnf', 'cnf_layer_38.cnf', 'cnf_layer_39.cnf', 'cnf_layer_40.cnf', 'cnf_layer_41.cnf', 'cnf_layer_42.cnf', 'cnf_layer_43.cnf', 'cnf_layer_44.cnf', 'cnf_layer_45.cnf',
 'cnf_layer_46.cnf', 'cnf_layer_47.cnf', 'cnf_layer_48.cnf', 'cnf_layer_49.cnf', 'cnf_layer_50.cnf', 'cnf_layer_51.cnf', 'cnf_layer_52.cnf', 'cnf_layer_53.cnf', 'cnf_layer_54.cnf',
 'cnf_layer_55.cnf', 'cnf_layer_56.cnf', 'cnf_layer_57.cnf', 'cnf_layer_58.cnf', 'cnf_layer_59.cnf', 'cnf_layer_60.cnf', 'cnf_layer_61.cnf', 'cnf_layer_62.cnf', 'cnf_layer_63.cnf',
 'cnf_layer_64.cnf', 'cnf_layer_65.cnf', 'cnf_layer_66.cnf', 'cnf_layer_67.cnf', 'cnf_layer_68.cnf', 'cnf_layer_69.cnf', 'cnf_layer_70.cnf', 'cnf_layer_71.cnf', 'cnf_layer_72.cnf']
    """
    # Create Z3 solver
    solver = Solver()

    # Apply AND operator recursively
    apply_and_recursive(solver, cnf_files)

    # Check satisfiability
    result = solver.check()
    if result == sat:
        print("Satisfiable")
        model = solver.model()
        print(model)
        #for d in model.decls():
        #    print(f"{d.name()} = {model[d]}")
    else:
        print("Unsatisfiable")"""
    for cnf1_file in cnf_files:
                cnf = CNF(from_file=cnf1_file)
                solver = Glucose3()
                solver.append_formula(cnf.clauses)
                result = solver.solve()
                if result:
                    print(f'{cnf1_file}: satisfiable')
                else:
                    print(f'{cnf1_file}: unsatisfiable')
