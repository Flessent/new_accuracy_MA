import numpy as np
from sklearn.model_selection import KFold
from sklearn.utils import shuffle
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import f1_score, confusion_matrix
from larq.layers import QuantDense
from tensorflow.keras.initializers import RandomNormal
import tensorflow as tf
from bnn import*
from circuits.timer import Timer
from circuits.linear import *
# Read the dataset from the text file
def read_dataset(filename):
    features = []
    labels = []
    with open(filename, 'r') as file:
        for line in file:
            label, feature = line.strip().split()
            labels.append(label)
            features.append(feature)
    return features, labels

# Encode labels as numerical values
def encode_labels(labels):
    label_encoder = LabelEncoder()
    encoded_labels = label_encoder.fit_transform(labels)
    return to_categorical(encoded_labels)

# Train the model
def print_model(model):
    model_vars = sorted(model.keys())
    print(" ".join("%d:%d" % (var,model[var]) for var in model_vars))
def train_model(X_train, y_train, X_test, y_test, model):
    print(y_train.shape)
    print(y_test.shape)

    # Convert features to numpy array
    X_train_encoded = np.array([[int(bit) for bit in feature] for feature in X_train])
    X_test_encoded = np.array([[int(bit) for bit in feature] for feature in X_test])
    print(X_train_encoded[:2])
    opt = tf.keras.optimizers.Adam(learning_rate=0.001)
    model.compile(loss='categorical_crossentropy', optimizer=opt, metrics=['accuracy'])

    # Train the model
    model.fit(X_train_encoded, y_train, epochs=20, batch_size=32, validation_split=0.2, shuffle=True,
              validation_data=(X_test_encoded, y_test))

    # Evaluate the model on train data
    _, accuracy = model.evaluate(X_train_encoded, y_train)
    accuracy_percentage = accuracy * 100
    print(f'Accuracy on train data: {accuracy_percentage:.2f}%')

    # Evaluate the model on test data
    _, accuracy = model.evaluate(X_test_encoded, y_test)
    accuracy_percentage = accuracy * 100
    print(f'Accuracy on test data: {accuracy_percentage:.2f}%')

    # Make predictions on test data
    y_pred = model.predict(X_test_encoded)
    y_pred_classes = np.argmax(y_pred, axis=1)
    y_test_classes = np.argmax(y_test, axis=1)

    # Calculate and print F1 score
    f1 = f1_score(y_test_classes, y_pred_classes, average='weighted')
    print(f'Weighted F1 Score: {f1:.2f}')

    # Print confusion matrix
    conf_matrix = confusion_matrix(y_test_classes, y_pred_classes)
    print('\nConfusion Matrix:')
    print(conf_matrix)

    # Print X Feature, True Label, Predicted Label
    print('\nX Feature, True Label, Predicted Label:')
    for i in range(len(X_test_encoded)):
        print(f'{X_test[i]}, {labels[y_test_classes[i]]}, {labels[y_pred_classes[i]]}')
    model.set_weights([((i>0)*2-1)*(i.ndim==2)+(i)*(i.ndim==1) for i in model.get_weights()])
    loss, accuracy = model.evaluate(X_test_encoded, y_test)
    print(f"After Binarization  Training Accuracy: {accuracy * 100:.2f}%")

    print(model.layers[0].get_weights()[0])
    return model
if __name__ == "__main__":
    dataset_filename = "output.txt"
    model=BNN()

    # Read dataset
    features, labels = read_dataset(dataset_filename)

    # Encode labels
    encoded_labels = encode_labels(labels)

    # Number of splits for KFold (e.g., 5)
    n_splits = 5

    # Create KFold instance
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

    # Initialize a variable to accumulate accuracy scores
    total_accuracy = 0

    # Iterate over the folds
    for train_index, test_index in kf.split(features):
        # Shuffle the data for each fold
        X_train, y_train = np.array(features)[train_index], np.array(encoded_labels)[train_index]
        X_train, y_train = shuffle(X_train, y_train, random_state=42)

        X_test, y_test = np.array(features)[test_index], np.array(encoded_labels)[test_index]

        # Train and evaluate the model for each fold
        model=train_model(X_train, y_train, X_test, y_test,model)
    print('######################################################### BNN to CNF ###########################################################')
    neuron_counter=1
    for layer in model.layers:
            if isinstance(layer, QuantDense):

                layer_weights = layer.get_weights()[0]
                bias_layers=layer.get_weights()[1]
                #print(layer_weights)
                #all_weights = [int(weight) for sublist in layer_weights for weight in sublist]
                #print(all_weights)


                for i in range(len(layer_weights)):
                    weights = [int(weight) for weight in layer_weights[i]]
                    print('Layer Weights :', layer_weights)
                    #c = Classifier(name=f'test_keras_layer_{layer_counter}', size=str(len(all_weights)), weights=all_weights, threshold=1)
                    #threshold = np.ceil ( ( (-layer.get_weights()[1] + np.sum(layer_weights)) / 2) ).astype(int) + np.sum((-layer_weights + 1) / 2)
                    c = Classifier(name=f'test_keras_layer_{neuron_counter}', size=str(len(weights)), weights=weights, threshold=26)


                    print("=== INPUT NEURON:")
                    print('Classifier Content:', c)
                    assert c.is_integer
                    print("=== NEURON TO OBDD:")
                    with Timer("compiling"):
                        obdd_manager, node = c.compile()
                    with Timer("size"):
                        count_before = len(list(node))
                    with Timer("reducing"):
                        node = node.reduce()
                    with Timer("size"):
                        count_after = len(list(node))
                    print("node count before reduce: %d" % count_before)
                    print("node count after reduce: %d" % count_after)

                    print("=== OBDD:")
                    print("model count: %d" % node.model_count(obdd_manager.var_count))
                    print("models:")
                    for model in node.models():
                        print_model(model)
                    print("non-models:")
                    for model in node.non_models():
                        print_model(model)

                    # Save OBDD image
                    obdd_filename = f'obdd_neuron_{neuron_counter}.png'
                    obdd_manager.obdd_to_png(node, obdd_filename)
                    print(f"Saved OBDD image for layer {neuron_counter} to {obdd_filename}")

                    # Save CNF file
                    cnf_filename = f'cnf_neuron_{neuron_counter}.cnf'
                    cnf,output_wire=obdd_manager.obdd_to_cnf(node, 1)
                    dimacs_file_path = os.path.join('cnf_files', cnf_filename)  # Create a folder to store CNF files
                    with open(dimacs_file_path, 'w') as dimacs_file:
                        dimacs_file.write(f"p cnf {cnf.var_count} {len(cnf.clauses)}\n")
                        for clause in cnf.clauses:
                            dimacs_file.write(" ".join(map(str, clause)) + " 0\n")
                    print(f"Saved CNF file for layer {neuron_counter} to {dimacs_file_path}")

                    neuron_counter += 1

   
