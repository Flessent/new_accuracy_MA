from circuits.timer import Timer
from circuits.linear import *
from keras.models import Sequential
from keras.layers import Dense
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import precision_score, recall_score, f1_score
from tensorflow.keras.callbacks import EarlyStopping
from larq.layers import QuantDense
from keras.callbacks import LearningRateScheduler
from sklearn.metrics import accuracy_score
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import larq as larq
from bnn import *
from cnf import *
from bnn_to_cnf import*
from circuits.timer import Timer
from circuits.linear import *
import math
from pysat.solvers import Glucose3
from pysat.formula import CNF
import itertools
from sklearn.preprocessing import StandardScaler, LabelEncoder
import numpy as np 
import pandas as pd
import keras.backend as K
import matplotlib.pyplot as plt
from tensorflow.keras import  optimizers
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import OneHotEncoder
from tensorflow.keras.layers import Layer
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.utils import shuffle
from tensorflow.keras.initializers import  RandomNormal

def print_model(model):
    model_vars = sorted(model.keys())
    print(" ".join("%d:%d" % (var,model[var]) for var in model_vars))

if __name__ == '__main__':
     np.random.seed(42)

     # Function to generate a random binary string of given size
     def generate_binary_string(size):
        return ''.join(np.random.choice(['0', '1'], size=size))

     # Number of samples in the dataset
     num_samples = 1000
     opt = larq.optimizers.Bop(threshold=1e-02, gamma=0.01, name="Bop")
     # Generate X features and y target variables
     X = np.array([list(generate_binary_string(18)) for _ in range(num_samples)])
     y = np.array([list(generate_binary_string(4)) for _ in range(num_samples)])

     # Convert binary strings to integers
     X = X.astype(int)
     y = y.astype(int)

     # Split the dataset into training and testing sets
     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

     print('Data X :', X)
     print('Label Y', y)

     # Normalize the input data
     scaler = StandardScaler()
     X_train_normalized = scaler.fit_transform(X_train)
     X_test_normalized = scaler.transform(X_test)

     # Reshape the data for CNN (assuming data represents sequences)
     #X_train_cnn = X_train_normalized.reshape((-1, 18, 1))
     #X_test_cnn = X_test_normalized.reshape((-1, 18, 1))
     X_train_cnn = X_train.reshape((X_train.shape[0], -1))
     X_test_cnn = X_test.reshape((X_test.shape[0], -1))


     # Shuffle the training data
     X_train_cnn, y_train = shuffle(X_train_cnn, y_train, random_state=42)

     # Print shapes of the datasets
     print("X_train shape:", X_train_cnn.shape)
     print("y_train shape:", y_train.shape)
     print("X_test shape:", X_test_cnn.shape)
     print("y_test shape:", y_test.shape)
     model=BNN()
     model.compile(optimizer=opt, loss='binary_crossentropy', metrics=['accuracy'])

    # Train the CNN model
     cnn_history = model.fit(X_train_cnn, y_train, epochs=25, batch_size=64, validation_split=0.2, verbose=1)
     """

     plt.plot(cnn_history.history['accuracy'], label='train_accuracy')
     plt.plot(cnn_history.history['val_accuracy'], label='val_accuracy')
     plt.xlabel('Epoch')
     plt.ylabel('Accuracy')
     plt.legend()
     plt.show()"""

     # Evaluate the CNN model on the test set
     cnn_loss, cnn_accuracy = model.evaluate(X_test_cnn, y_test)
     print(f"CNN Test Loss: {cnn_loss:.4f}")
     print(f"CNN Test Accuracy: {cnn_accuracy * 100:.2f}%")
     for layer in model.layers:
        if isinstance(layer, Conv1D):
            print(layer.get_weights()[0])

     datafile = 'weights_after_training.tf'

     model.save_weights(datafile)
     

     cnf_clauses = Cnf([])
     
     #dim= [ [18,18], [18,18],[18,18],[18,4],[4,] ]
     input_dim=18
     num_neuron_in_hidden_dense_layer=18
     num_neuron_output_layer=4
     dim = [
    (input_dim, num_neuron_in_hidden_dense_layer),
    (num_neuron_in_hidden_dense_layer, num_neuron_in_hidden_dense_layer),
    (num_neuron_in_hidden_dense_layer, num_neuron_in_hidden_dense_layer),
    (num_neuron_in_hidden_dense_layer, num_neuron_output_layer)
]

     print('################################################### Encoding Process starts... ###########################################################################')

     #linear_layer_weights, linear_layer_biases = bnn_model.get_layer('linear_layer_name').get_weights()
     #print("Linear Layer Weights:", linear_layer_weights)
     #print("Linear Layer Biases:", linear_layer_biases)
     data = [
    ("000110101111001101", "0001"),
    ("101010010000111101", "0001"),
    ("010000110011001101", "1111"),
    ("101001010000110101", "0110"),
    ("010101011111000101", "0101"),
    ("011100001100111101", "1000"),
    ("000101111100000101", "0111"),
    ("011000001001110101", "0111"),
    ("101001000111000101", "0111"),
    ("100001100000111101", "1110"),
    ("110000010011000101", "0110"),
    ("000110110110001101", "0000"),
    ("100101000011000101", "0000"),
    ("011011011111000101", "1001"),
    ("101111110000111101", "0111"),
    ("000010011100000101", "1001"),
    ("110010111111001101", "0111"),
    ("100000001111001101", "1000"),
    ("010100100000110101", "0010"),
    ("010110101111000101", "1010"),
    ("110100100000110101", "0100"),
    ("000111101111000101", "1110")
]

     # Create separate lists for X (input data) and y (label) using list comprehension
     X = [row[0] for row in data]
     y = [row[1] for row in data]

     print('dim[0][0]', dim[0][0])

     #input_terms = [Term(annotation='in' + str(i)) for i in dim[0][0]]
     input_data = "010111111011001101"
     input_terms = [Term(annotation='in' + str(i)) if bit == '1' else Term(annotation='in' + str(i)).neg() for i, bit in enumerate(input_data)]

     print('input_terms :', input_terms)
     output_terms = input_terms
     print('NUM layers :', len(model.layers))

     for layer, layer_id in zip(model.layers, range(len(model.layers))):
        if isinstance(layer, QuantDense):
            if layer.name!= 'linear_layer_output' :
                #x = layer.get_input()
                weights_in = layer.get_weights()[0]  
                biases_in = layer.get_weights()[1]
                print('layer.get_weights()[0]:', weights_in)
                #print('layer_id:', layer_id)
                #print('Internal :', layer.name)
                #print('second part', np.sum((-weights_in + 1) / 2))
                threshold = np.ceil ( ( (-biases_in + np.sum(weights_in)) / 2) ).astype(int) + np.sum((-weights_in + 1) / 2) 

                print('Weights INPUT',weights_in.shape)



                (output_terms, output_clauses) = internal_layer_to_cnf(output_terms, weights_in, threshold, 'L'+ str(layer_id))
                #print(f'output_terms Internal: {output_terms[0]}')
               
            if layer.name=='linear_layer_output':
                #input_terms = [Term(annotation='out' + str(i)) for i in range(dim[-1][0])]
                #output_terms= input_terms
                weights_out = layer.get_weights()[0] 
                biases_out = layer.get_weights()[1]
                #print('layer_id :',layer_id)

                print('External :', layer.name)
                print('weights LAST :', weights_out)
                #print('weights ALL :', weights_out)
                threshold = np.ceil ( ( (-biases_out + np.sum(weights_out)) / 2) ).astype(int) + np.sum((-weights_out + 1) / 2)

                (output_terms, output_clauses) = output_layer_to_cnf(output_terms, weights_out.T, threshold, 'L' + str(layer_id))
                #print(f'output_clauses External: {type(output_clauses)}')
            
            cnf_clauses += output_clauses

     #variable_info= get_variable_info(cnf_clauses)

     s = set()
     d = {}
     for clause in cnf_clauses.clauses:
        #print((clause))
        for term in clause.terms:
            s.add(abs(term.tid))

     sorted_s = sorted(s)
     for i, tid in enumerate(sorted_s):
        d[tid] = i + 1

     cnf_array = []
     for clause in cnf_clauses.clauses:
        clause_array = []
        for term in clause.terms:
            clause_array.append(d[abs(term.tid)] * sign(term.tid))

        cnf_array.append(clause_array)

     swap0 = dim[0][0] + 1
     #for layer_dimensions in dim[1:]:
        #swap0 += layer_dimensions[0] + 1

     #print('swap0 :',swap0)
     swap1 = d[abs(output_terms[0].tid)]
     for i, clause in enumerate(cnf_array):
        #print(cnf_array)
        for j, term in enumerate(clause):
            if abs(term) == swap0:
                cnf_array[i][j] = swap1 * sign(term)
            elif abs(term) == swap1:
                cnf_array[i][j] = swap0 * sign(term)

     print("swapped %d with %d" % (swap0, swap1))
     output_file='bnntocnf.cnf'
     #write_variable_info(variable_info, output_file)
     #write_output(cnf_array, len(s), output_file)
     #check_variable_assignment(output_file)

     print('################################################### End of the Encoding Process !!!  ###########################################################################')
     model.save("model.h5")
     larq.models.summary(model)
     neuron_counter=1

     for layer in model.layers:
        if isinstance(layer, QuantDense) or isinstance(layer, Conv1D):

            layer_weights = layer.get_weights()[0]
            bias_layers=layer.get_weights()[1]
            #print(layer_weights)
            #all_weights = [int(weight) for sublist in layer_weights for weight in sublist]
            #print(all_weights)


            for i in range(len(layer_weights)):
                weights = [int(weight) for weight in layer_weights[i]]
                print('Layer Weights :', layer_weights)
                #c = Classifier(name=f'test_keras_layer_{layer_counter}', size=str(len(all_weights)), weights=all_weights, threshold=1)
                #threshold = np.ceil ( ( (-layer.get_weights()[1] + np.sum(layer_weights)) / 2) ).astype(int) + np.sum((-layer_weights + 1) / 2)
                c = Classifier(name=f'test_keras_layer_{neuron_counter}', size=str(len(weights)), weights=weights, threshold=99)


                print("=== INPUT NEURON:")
                print('Classifier Content:', c)
                assert c.is_integer
                print("=== NEURON TO OBDD:")
                with Timer("compiling"):
                    obdd_manager, node = c.compile()
                with Timer("size"):
                    count_before = len(list(node))
                with Timer("reducing"):
                    node = node.reduce()
                with Timer("size"):
                    count_after = len(list(node))
                print("node count before reduce: %d" % count_before)
                print("node count after reduce: %d" % count_after)

                print("=== OBDD:")
                print("model count: %d" % node.model_count(obdd_manager.var_count))
                print("models:")
                for model in node.models():
                    print_model(model)
                print("non-models:")
                for model in node.non_models():
                    print_model(model)

                # Save OBDD image
                obdd_filename = f'obdd_neuron_{neuron_counter}.png'
                obdd_manager.obdd_to_png(node, obdd_filename)
                print(f"Saved OBDD image for layer {neuron_counter} to {obdd_filename}")

                # Save CNF file
                cnf_filename = f'cnf_neuron_{neuron_counter}.cnf'
                cnf,output_wire=obdd_manager.obdd_to_cnf(node, 1)
                dimacs_file_path = os.path.join('cnf_files', cnf_filename)  # Create a folder to store CNF files
                with open(dimacs_file_path, 'w') as dimacs_file:
                    dimacs_file.write(f"p cnf {cnf.var_count} {len(cnf.clauses)}\n")
                    for clause in cnf.clauses:
                        dimacs_file.write(" ".join(map(str, clause)) + " 0\n")
                print(f"Saved CNF file for layer {neuron_counter} to {dimacs_file_path}")

                neuron_counter += 1


