import larq as larq
import larq.layers
import tensorflow as tf
from activations import *
import seaborn as sbn
import boto
from kiwisolver import Solver
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
from tensorflow.keras import models, layers
from tensorflow.keras.datasets import mnist
import numpy as np
import matplotlib.pyplot as plt
import os
import psutil
import time
import sys
import ast
from z3 import *
from larq.layers import QuantDense
from tensorflow.keras.layers import  Lambda,BatchNormalization
from tensorflow.python.framework import ops
from tensorflow.keras.layers import Dense, BatchNormalization, Dropout, Conv1D, Flatten
from tensorflow.keras.initializers import RandomNormal


class BNN(models.Sequential):
    def __init__(self):
        super().__init__()
        """
        kwargs = dict(
            input_quantizer="ste_sign",
            kernel_quantizer="ste_sign",
            kernel_constraint="weight_clip",
            use_bias=True
        )

        self.add(QuantDense(18, activation='relu', input_shape=(18, ),kernel_quantizer='ste_sign', kernel_constraint='weight_clip' ))
        self.add(BatchNormalization())
        #self.add(Flatten())
        #self.add(QuantDense(18, activation='relu', **kwargs))
        #self.add(BatchNormalization())
        #self.add(Dropout(0.5))
        #self.add(QuantDense(18, activation='relu', **kwargs))
        self.add(QuantDense(4, activation='sigmoid', name='linear_layer_output', **kwargs))"""
        kwargs = dict(
        kernel_quantizer="ste_sign",
        kernel_constraint="weight_clip",
        use_bias=True,
        kernel_initializer=RandomNormal(stddev=0.1),
        bias_initializer=RandomNormal(stddev=0.1),
    )

        self.add(QuantDense(55, input_dim=14, kernel_quantizer="ste_sign"))
        self.add(QuantDense(20, kernel_quantizer="ste_sign", kernel_constraint="weight_clip"))
        self.add(QuantDense(20, kernel_quantizer="ste_sign", kernel_constraint="weight_clip"))
        self.add(QuantDense(9, activation='softmax', **kwargs))
